import { useState, useRef } from 'react';
import { Heart, Sparkles } from 'lucide-react';
import FallingHearts from './components/FallingHearts';
import LoveTimer from './components/LoveTimer';
import MusicButton from './components/MusicButton';
import LoveModal from './components/LoveModal';

const HER_NAME = 'My Beloved';
const START_DATE = new Date('2024-01-01');
const MUSIC_SRC = 'https://www.w3schools.com/html/horse.mp3';

const loveLines = [
  'Every day with you feels like a dream',
  'I never want to wake up from.',
  'You are my happiness, my peace,',
  'and my greatest adventure.',
  'The world becomes brighter when you smile,',
  'and my heart beats only for you.',
];

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const btnRef = useRef<HTMLButtonElement>(null);
  const rippleCounter = useRef(0);

  const handleButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = btnRef.current!.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = rippleCounter.current++;
    setRipples((prev) => [...prev, { id, x, y }]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 700);
    setModalOpen(true);
  };

  return (
    <div
      className="relative min-h-screen flex flex-col items-center justify-center px-4 py-16 overflow-hidden"
      style={{
        background:
          'linear-gradient(135deg, #f43f5e 0%, #fb7185 20%, #fda4af 45%, #fdba74 75%, #fcd34d 100%)',
      }}
    >
      <FallingHearts />

      <MusicButton src={MUSIC_SRC} />

      <div
        className="relative z-10 w-full max-w-xl flex flex-col items-center gap-8 animate-fade-in-up"
      >
        <div className="animate-float">
          <Heart
            size={64}
            className="text-white drop-shadow-lg animate-heartbeat"
            fill="currentColor"
          />
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <Sparkles size={16} className="text-white/70" />
            <span
              className="text-white/80 uppercase tracking-widest"
              style={{ fontFamily: "'Lato', sans-serif", fontSize: '0.75rem', letterSpacing: '0.22em' }}
            >
              A love letter
            </span>
            <Sparkles size={16} className="text-white/70" />
          </div>

          <h1
            className="shimmer-text leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 'clamp(2rem, 6vw, 3.2rem)',
              fontWeight: 700,
            }}
          >
            For {HER_NAME}
          </h1>
        </div>

        <div
          className="glass-card rounded-3xl px-8 py-8 w-full shadow-2xl text-center animate-pulse-glow"
        >
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="h-px flex-1 bg-white/30" />
            <Heart size={14} fill="currentColor" className="text-white/60" />
            <div className="h-px flex-1 bg-white/30" />
          </div>

          <div className="space-y-1 mb-6">
            {loveLines.map((line, i) => (
              <p
                key={i}
                className="text-white/90"
                style={{
                  fontFamily: i % 2 === 0 ? "'Playfair Display', serif" : "'Lato', sans-serif",
                  fontStyle: i % 2 === 0 ? 'italic' : 'normal',
                  fontSize: i % 2 === 0 ? '1.1rem' : '1rem',
                  fontWeight: i % 2 === 0 ? 400 : 300,
                  lineHeight: 1.8,
                  letterSpacing: i % 2 !== 0 ? '0.02em' : undefined,
                }}
              >
                {line}
              </p>
            ))}
          </div>

          <div className="flex items-center justify-center gap-3 mt-6 mb-2">
            <div className="h-px flex-1 bg-white/30" />
            <Heart size={14} fill="currentColor" className="text-white/60" />
            <div className="h-px flex-1 bg-white/30" />
          </div>
        </div>

        <LoveTimer startDate={START_DATE} />

        <button
          ref={btnRef}
          onClick={handleButtonClick}
          className="btn-love relative text-white font-semibold rounded-full px-10 py-4 shadow-xl"
          style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: '1rem',
            letterSpacing: '0.06em',
            background: 'rgba(255,255,255,0.22)',
            border: '1.5px solid rgba(255,255,255,0.5)',
          }}
        >
          {ripples.map((r) => (
            <span
              key={r.id}
              className="ripple-circle"
              style={{
                width: 20,
                height: 20,
                left: r.x - 10,
                top: r.y - 10,
              }}
            />
          ))}
          <span className="relative z-10 flex items-center gap-2">
            <Heart size={16} fill="currentColor" />
            A Message for You
            <Heart size={16} fill="currentColor" />
          </span>
        </button>

        <p
          className="text-white/50 text-xs"
          style={{ fontFamily: "'Lato', sans-serif", letterSpacing: '0.1em' }}
        >
          made with love, always
        </p>
      </div>

      {modalOpen && <LoveModal onClose={() => setModalOpen(false)} />}
    </div>
  );
}
